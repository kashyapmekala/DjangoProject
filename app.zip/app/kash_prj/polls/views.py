from django.shortcuts import render
from django.http import HttpResponse

def index(request):
# should access Model object and use Templates to prepare responses

	return HttpResponse('Hello World')
# Create your views here.
# Create your views here.
